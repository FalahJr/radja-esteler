<footer class="main-footer">
    <strong>Copyright &copy; 2024 Radja Es Teler Sultan.</strong>

</footer>