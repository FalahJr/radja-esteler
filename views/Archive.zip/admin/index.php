<?php

// use Yii;

$this->title = 'Dashboard Admin';
$this->params['breadcrumbs'] = [['label' => $this->title]];
// if (Yii::$app->user->isGuest) {
//     return $this->redirect(["public/login"]);
// }
?>
<div class="container-fluid">


    <div class="row">
        <div class="col-12 d-flex flex-column justify-content-center align-items-center" style="height:55vh">
            <h1>Selamat Datang Di Dashboard Radja Es Teler Sultan</h1>
        </div>
    </div>


</div>